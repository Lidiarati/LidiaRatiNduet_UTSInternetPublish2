# Credits

There are many people who helped to make bootstrap-progressbar great.

Contributions are always welcome!


* Stephan Groß - [minddust](https://github.com/minddust)
* Shantibhushan Naik - [visitsb](https://github.com/visitsb)
* Maciek Gajewski - [konieczkow](https://github.com/konieczkow)
* Şəhriyar İmanov - [shehi](https://github.com/shehi)
* Henrik - [HaNdTriX](https://github.com/HaNdTriX)
